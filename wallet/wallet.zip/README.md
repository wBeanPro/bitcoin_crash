# simple-node-bitcoin-wallet
Simple Nodejs App to manage your bitcoin wallet

A light and simple app for managing your Bitcoin wallet.

After starting bitcoin full node, install all nodejs modules with <code>npm install </code> then type <code>node index.js</code> to start app.

navigate to app by typing:

<code>YOUR_SERVER_IP:3008</code>

Default password is:

<code>123456</code>

You can change password from index.js file.

done.
